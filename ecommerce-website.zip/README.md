# E-Commerce Website
This is a simple e-commerce website with 10 pages using HTML, CSS, and JavaScript.

## Features:
- Home Page
- Shop Page
- Product Page
- Cart & Checkout
- Login & Signup
- About, Contact & FAQ

### How to Run:
1. Extract the ZIP file
2. Open `index.html` in a browser
